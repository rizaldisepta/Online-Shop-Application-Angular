import { Component } from '@angular/core';
import { AttrAst } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title2 = 'The Jungle';
  saya = "ganteng ";
  angka = 0;
  inputText = "";
  inputText2 = "";
  inputTextNama = "";
  inputTextJumlah = "";
  inputTextHarga = "";
  idxEdit;
  mode=1;
  
  heroes = [];

  changeText1(e){
    console.log("change text 1",e);
  }
  changeText2(e){
    console.log("change text 2",e);
  }
  changeText3(e){
    console.log("change text 3",e);
  }
  btnShowHeroes(idx){
    this.heroes = [{name:'aldi ', age:25},
                {name:'cyn ', age:44},
               {name:'Imam ', age:12},
               {name:'saipul ', age:43},
               {name:'hilal ', age:22}

    ]
  }
  btnAddHeroes(){
    this.mode=1;
    this.heroes.push({name:this.inputTextNama,jumlah:this.inputTextJumlah,harga:this.inputTextHarga})
    this.inputTextNama="";
    this.inputTextJumlah="";
    this.inputTextHarga="";
  }
  deleteMsg(idx) {
    if (idx !== -1) {
        this.heroes.splice(idx, 1);
    }        
}
  edit(idx) {
      this.mode=2;
      this.inputTextNama= this.heroes[idx].name;
      this.inputTextJumlah= this.heroes[idx].jumlah;
      this.inputTextHarga= this.heroes[idx].harga;
      this.idxEdit=idx;
}
  update(idxEdit){
    this.heroes[idxEdit].name=this.inputTextNama;
    this.heroes[idxEdit].jumlah=this.inputTextJumlah;;
    this.heroes[idxEdit].harga=this.inputTextHarga;
    this.mode=1;
    this.inputTextNama="";
    this.inputTextJumlah="";
    this.inputTextHarga="";
  }
//
}
